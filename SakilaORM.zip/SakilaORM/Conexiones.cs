﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Odbc;

using System.Xml;

public class Class1
{

    public class Conexiones
    {



        public string conectar()
        {

            return cadcon = "Driver={MySql ODBC 3.51 Driver};Server=192.168.12.7;Database=sifmun_v2;User=root;Password=123;Option=3;";


        }

        public string cadcon { get; set; }

    }

     public string conectarConta()
        {

           
          
            return cadconta =""  ; // Driver={MySql ODBC 3.51 Driver};Server=" + srv + ";Database=Gsisoft;User=root;Password=" + pas + ";Option=3;";

        

        }

        

        public string cadconta { get; set; }
    }


