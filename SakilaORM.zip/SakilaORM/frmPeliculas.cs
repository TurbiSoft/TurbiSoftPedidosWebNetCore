using Org.BouncyCastle.Bcpg.OpenPgp;
using Org.BouncyCastle.Utilities.Collections;
using SakilaContext;
using System.Data;
using System.Diagnostics;
using TurbiSoft;
using Devart.Data.Linq.Monitoring;
using Devart.Data.Linq;
using System.Runtime.CompilerServices;
using NetTopologySuite.IO;
using NetTopologySuite.Geometries;
using Org.BouncyCastle.Pqc.Crypto.Lms;
// using System.Data.Spatial; // Necesario para DbGeometry


namespace SakilaORM
{
    public partial class frmPeliculas : frmBase
    {

        public String cModo = "Inicio";
        String cCadenaConexion = "";

        const string cSYSTEM = "Pr�ctica SAKILA DB ORM";

        Procesos oProcesos = new Procesos();
        int nRegistros = 0;
        string cTablaMaestra = "Film";
        string cReporteMaestro = "";
        bool lVisualizaFoto = false;
        LinqMonitor linqMonitor1 = new LinqMonitor();


        public frmPeliculas()
        {
            InitializeComponent();
        }

        private void frmPeliculas_Load(object sender, EventArgs e)
        {
            linqMonitor1.IsActive = true;  // para monitorear las consultas LINQ
            this.Iniciar();
            Procesos.LlenaComboBox(cboLenguaje, "language", "language_id", "name", "language_id", 0);
            Procesos.LlenaComboBox(cboClasificacionRating, "tiporating", "ratingid", "nomrating", "ratingid", 0);
            //  Procesos.LlenaComboBox(cboTipoNovedad, "tiponovedad", "idtiponovedad", "nomnovedad", "idtiponovedad", 0);

            /*
            using (SakilaDataContext db = new SakilaDataContext())
            {
                Console.WriteLine("Connected to MySQL database!");

                // LINQ Query: Fetch first 10 actors
                var actors = db.Actor.Take(10).ToList();

                // Display data
                string cActores = "";
                Console.WriteLine("Actors List:");
                foreach (var oActor in actors)
                {
                    cActores =+ oActor.ActorId +" "+ oActor.LastName + " " + oActor.LastName;
                }
                MessageBox.Show("Actores: " + cActores, cSYSTEM, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            */
        }

        private void cmdSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        protected void Iniciar()
        {
            this.cModo = "Inicio";
            this.Limpiar();
            this.Botones();

        }


        protected void Limpiar()
        {
            Procesos.LimpiarTextBox(txtCodigo);
            oProcesos.LimpiarControles(this);
            dtpLastUpdate.Value = DateTime.Now;

            txtCostoReemplazo.Text = "0.00";
            txtDuracionRenta.Text = "0";
            txtLongitudDuracion.Text = "0";
            txtReleaseYear.Text = "0";
            txtTasaRenta.Text = "0.00";
            txtTitulo.Text = "";
            txtDescripcion.Text = "";
            txtCaracteristicas.Text = "";
            dtpLastUpdate.Value = DateTime.Now;
            //cboClasificacionRating.SelectedIndex = 0; // Selecciona el primer elemento por defecto  
            //cboLenguaje.SelectedIndex = 0; // Selecciona el primer elemento por defecto 



        } // fin Limpiar

        // Habiltia y desabilita botones
        protected void Botones()
        {
            switch (cModo)
            {
                case "Inicio":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = true;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    this.cmdEditar.Enabled = false;
                    oProcesos.LimpiarControles(this);
                    Procesos.Deshabilitar(this);
                    // txtcodigo.ReadOnly = false;
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                    this.UseWaitCursor = false;
                    Application.UseWaitCursor = false;

                    break;
                case "Nuevo":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = true;
                    this.cmdEditar.Enabled = false;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    Procesos.Habilitar(this);
                    // oProcesos.LimpiarControles(this);
                    break;

                case "Grabar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Eliminar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Cancelar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                    this.UseWaitCursor = false;
                    Application.UseWaitCursor = false;
                    break;

                case "Buscar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = true;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = false;
                    this.cmdEditar.Enabled = true;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Actualiza":
                    this.cmdBorrar.Enabled = true;
                    this.cmdBuscar.Enabled = true;
                    //this.cmdLocaliza.Enabled = true;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = true;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    this.cmdEditar.Enabled = true;
                    Procesos.Habilitar(this);
                    break;

                default:
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;
            }

            // Valida permisos del usuario
            /*
            this.cmdNuevo.Enabled = FrmMenInicio.oUserLogin.TienePermiso("110") && this.cmdNuevo.Enabled;
            this.cmdGrabar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("110") && this.cmdGrabar.Enabled;
            this.cmdEditar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("111") && this.cmdEditar.Enabled;
            this.cmdBuscar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("112") && this.cmdBuscar.Enabled;
            this.cmdBorrar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("113") && this.cmdBorrar.Enabled;
            this.cmdPrinter.Enabled = FrmMenInicio.oUserLogin.TienePermiso("112") && this.cmdPrinter.Enabled;
            */

        } // fin Botones

        public static void Habilitar(Control c)
        {
            string cBasura = "";
            foreach (Control Ctrl in c.Controls)
            {
                try
                {
                    //Console.WriteLine(Ctrl.GetType().ToString());
                    //MessageBox.Show ( (Ctrl.GetType().ToString())) ;
                    switch (Ctrl.GetType().ToString())
                    {
                        case "System.Windows.Forms.CheckBox":
                            ((CheckBox)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.TextBox":
                            //((TextBox)Ctrl).Text = "";
                            ((TextBox)Ctrl).ReadOnly = false;
                            ((TextBox)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.RadioButton":
                            ((RadioButton)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.ComboBox":
                            ((ComboBox)Ctrl).Enabled = true;

                            break;

                        case "System.Windows.Forms.MaskedTextBox":
                            ((MaskedTextBox)Ctrl).ReadOnly = false;
                            break;

                        case "System.Windows.Forms.DateTimePicker":
                            ((DateTimePicker)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.DataGridView":
                            ((DataGridView)Ctrl).Enabled = true;
                            break;

                        // los habilito en Botones() del form
                        case "System.Windows.Forms.Button":
                            // ((MaskedTextBox)Ctrl).ReadOnly = false;
                            break;


                        case "DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn":
                            // ((DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn)Ctrl).Enabled = false;
                            Ctrl.Enabled = true;
                            break;


                        default:
                            if (Ctrl.Controls.Count > 0)
                            {
                                //  Deshabilitar(Ctrl); temporal 05-11-2024
                                int n = 1;
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                    MessageBox.Show("Error, Detalle: " + cMensajeError, "Resetear Controles, Sistema TurbiSoft Enterprise v1.0",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    return;
                }
                finally
                {

                }
            }
        }

        private void cmdNuevo_Click(object sender, EventArgs e)
        {
            try
            {
                cModo = "Nuevo";
                this.Botones();
                Habilitar();
                ProximoCodigo();
                this.txtTitulo.Focus();
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Error, Detalle: " + cMensajeError, "Resetear Controles, Sistema TurbiSoft Enterprise v1.0",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }
        }

        private void cmdGrabar_Click(object sender, EventArgs e)
        {
            bool lGrabado = true;
            string cMensajeError = "";
            try
            {
                if (cboClasificacionRating.SelectedValue.ToString().Trim() == "")
                {
                    cboClasificacionRating.SelectedValue = 1;
                }


                Cursor.Current = Cursors.WaitCursor;

                SakilaDataContext DBContext = new SakilaDataContext();
                if (cModo == "Nuevo")
                {
                    Film oFilm = new Film();
                    // oFilm.FilmId = Convert.ToInt32(txtCodigo.Text.Trim());
                    oFilm.Description = txtDescripcion.Text.Trim();
                    oFilm.Title = txtTitulo.Text.Trim();
                    oFilm.ReleaseYear = Convert.ToInt16(txtReleaseYear.Text.Trim());
                    oFilm.RentalDuration = Convert.ToInt32(txtDuracionRenta.Text);
                    oFilm.LanguageId = Convert.ToInt32(cboLenguaje.SelectedValue);
                    //oFilm.OriginalLanguageId = Convert.ToInt32(cboLenguaje.SelectedValue);
                    oFilm.RentalRate = Convert.ToDecimal(txtTasaRenta.Text.Trim());
                    oFilm.Length = Convert.ToInt32(txtLongitudDuracion.Text.Trim());
                    oFilm.ReplacementCost = Convert.ToDecimal(txtCostoReemplazo.Text.Trim());
                    oFilm.Ratingid = Convert.ToInt32(cboClasificacionRating.SelectedValue);
                    oFilm.SpecialFeatures = txtCaracteristicas.Text.Trim();
                    oFilm.LastUpdate = dtpLastUpdate.Value;
                    //  oFilm.Rating =  Convert.ToInt32(txtLongitudDuracion.Text.Trim());


                    // Validos tablas relacionadas


                    // Inserto y grabo
                    DBContext.Film.InsertOnSubmit(oFilm);
                    DBContext.SubmitChanges();

                    if (lGrabado)
                    {
                        var oUltimo = DBContext.ExecuteQuery<int>("select last_insert_id() as cLastID");
                        if (oUltimo != null)
                            foreach (int id in oUltimo)

                                MessageBox.Show("Registro insertado satisfactoriamente con la secuencia: " + id.ToString(), cSYSTEM,
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Limpiar();
                        this.Botones();
                    }
                }
                else //  Modificando Update
                {
                    var oConsulta = from Film in DBContext.Film
                                    where Film.FilmId == Convert.ToInt32(txtCodigo.Text)
                                    select Film;

                    Film oFilm = oConsulta.FirstOrDefault();
                    if (oConsulta == null)
                    {
                        MessageBox.Show("Error para Actualizar, no encontr� el registro!!!", cSYSTEM,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Cursor.Current = Cursors.Default;
                        this.Cursor = Cursors.Default;
                        this.UseWaitCursor = false;
                        Application.UseWaitCursor = false;
                        return;
                    }


                    oFilm.FilmId = Convert.ToInt32(txtCodigo.Text.Trim());
                    oFilm.Description = txtDescripcion.Text.Trim();
                    oFilm.Title = txtTitulo.Text.Trim();
                    oFilm.ReleaseYear = Convert.ToInt16(txtReleaseYear.Text.Trim());
                    oFilm.RentalDuration = Convert.ToInt32(txtDuracionRenta.Text);
                    oFilm.LanguageId = Convert.ToInt32(cboLenguaje.SelectedValue);
                    //oFilm.OriginalLanguageId = Convert.ToInt32(cboLenguaje.SelectedValue);
                    oFilm.RentalRate = Convert.ToDecimal(txtTasaRenta.Text.Trim());
                    oFilm.Length = Convert.ToInt32(txtLongitudDuracion.Text.Trim());
                    oFilm.ReplacementCost = Convert.ToDecimal(txtCostoReemplazo.Text.Trim());
                    oFilm.Ratingid = Convert.ToInt32(cboClasificacionRating.SelectedValue);
                    oFilm.SpecialFeatures = txtCaracteristicas.Text.Trim();
                    oFilm.LastUpdate = dtpLastUpdate.Value;
                    //  oFilm.Rating =  Convert.ToInt32(txtLongitudDuracion.Text.Trim())

                    // Validos tablas relacionadas


                    // Actualizo cambios en la BD
                    DBContext.SubmitChanges();
                    lGrabado = true;

                    if (lGrabado)
                    {
                        MessageBox.Show("Registro actualizado Satisfactoriamente!!", cSYSTEM,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Limpiar();
                        this.Botones();
                    }
                }

            }
            catch (Exception ex)
            {
                cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();

                MessageBox.Show("Error insertando y/o Actualizando Registro, Detalle6: " + cMensajeError, cSYSTEM,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                lGrabado = false;
                return;
            }
        }

        private void cmdBuscar_Click(object sender, EventArgs e)
        {
            string cMensajeError = "";
            try
            {
                int nFildID = 1;// ofrmBuscar.nCodigo;

                string value = "0";
                int nSecuencia = 0;

                cModo = "Buscar";
                this.Limpiar();
                this.Botones();


                frmBuscarFilm ofrmBuscarEmpleados = new frmBuscarFilm();
                ofrmBuscarEmpleados.ShowDialog();
                this.txtCodigo.Text = ofrmBuscarEmpleados.cCodigo;
                if (txtCodigo.Text == "" || txtCodigo.Text == "0") { return; }

                using (SakilaDataContext DBContext = new SakilaDataContext())
                {
                    var oConsulta = from alias in DBContext.Film
                                    where alias.FilmId == Convert.ToInt64(txtCodigo.Text)
                                    select alias;

                    Film oFilm = oConsulta.FirstOrDefault();
                    if (oFilm == null)
                    {
                        MessageBox.Show("Error para Actualizar, no encontro el registro!!!", cSYSTEM, MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        Cursor.Current = Cursors.Default;
                        this.Cursor = Cursors.Default;
                        this.UseWaitCursor = false;
                        Application.UseWaitCursor = false;
                        return;
                    }

                    txtCodigo.Text = Convert.ToString(oFilm.FilmId).Trim();
                    txtDescripcion.Text = oFilm.Description.Trim();
                    txtTitulo.Text = oFilm.Title.Trim();
                    txtReleaseYear.Text = Convert.ToString(oFilm.ReleaseYear).Trim();
                    txtDuracionRenta.Text = Convert.ToString(oFilm.RentalDuration);
                    cboLenguaje.SelectedValue = Convert.ToInt32(oFilm.LanguageId);
                    //oFilm.OriginalLanguageId = Convert.ToInt32(cboLenguaje.SelectedValue);
                    txtLongitudDuracion.Text = Convert.ToString(oFilm.Length);
                    txtCostoReemplazo.Text = Convert.ToDecimal(oFilm.ReplacementCost).ToString().Trim();
                    cboClasificacionRating.SelectedValue = Convert.ToInt32(oFilm.Ratingid);
                    txtCaracteristicas.Text = oFilm.SpecialFeatures.Trim();
                    dtpLastUpdate.Value = oFilm.LastUpdate;
                    //  oFilm.Rating =  Convert.ToInt32(txtLongitudDuracion.Text.Trim())


                    // Busco tablas relacionadas
                    BuscarTablasRelacionadas(Convert.ToInt32(txtCodigo.Text));

                    oProcesos.AbilitarDesabilitarControles(this, true);
                    //Habilitar();
                    this.cModo = "Buscar";
                    this.Botones();
                    this.txtCodigo.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();

                MessageBox.Show("Error insertando y/o Actualizando Registro, Detalle6: " + cMensajeError, cSYSTEM,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }

        private void cmdBorrar_Click(object sender, EventArgs e)
        {
            if (this.txtCodigo.Text == "")
            {
                return;
            }
            DialogResult oRpt;
            oRpt = MessageBox.Show("Confirma que desea eliminar este registro?", cSYSTEM,
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (oRpt != DialogResult.Yes) { return; }
            try
            {
                bool lBorrado = false;
                cModo = "Eliminar";

                // Devart.Data.MySql.MySqlConnection oConexion = Procesos.ObtieneConexionDevart();
                SakilaDataContext DBContext = new SakilaDataContext();
                var oConsulta = from alias in DBContext.Film
                                where alias.FilmId == Convert.ToInt32(this.txtCodigo.Text)
                                select alias;

                Film oFilm = oConsulta.FirstOrDefault();
                if (oFilm != null)
                {
                    DBContext.Film.DeleteOnSubmit(oFilm);
                    //DBContext.SubmitChanges(Devart.Data.Linq.ConflictMode.FailOnFirstConflict)
                    DBContext.SubmitChanges();
                    lBorrado = true;
                }

                if (lBorrado)
                {
                    MessageBox.Show("Registro Eliminado Satisfactoriamente!!", cSYSTEM,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Iniciar();
                }
                else
                {
                    MessageBox.Show("No se pudo Eliminar el registro!!", cSYSTEM,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.txtCodigo.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Error insertando Registro, Detalle: " + cMensajeError, cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }

        private void cmdEditar_Click(object sender, EventArgs e)
        {

            try
            {
                cModo = "Actualiza";
                Botones();
                oProcesos.AbilitarDesabilitarControles(this, true);
                Habilitar();
                cmdEditar.Enabled = false;
                cmdGrabar.Enabled = true;
                this.txtCodigo.Enabled = false;
                this.txtTitulo.Focus();
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Error, Detalle: " + cMensajeError, cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Iniciar();
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Error, Detalle: " + cMensajeError, cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }


        protected void DesHabilitar()
        {
            //txtcodigo.ReadOnly = true;
            oProcesos.AbilitarDesabilitarControles(this, false);
        }
        protected void Habilitar()
        {
            Procesos oProcesos = new Procesos();
            oProcesos.AbilitarDesabilitarControles(this, true);

            this.txtCodigo.ReadOnly = true;
            this.txtDescripcion.ReadOnly = false;
            this.txtDescripcion.Enabled = true;

            txtCaracteristicas.ReadOnly = false;
            txtCaracteristicas.Enabled = true;

            txtCostoReemplazo.ReadOnly = false;
            txtCostoReemplazo.Enabled = true;

            txtDuracionRenta.ReadOnly = false;
            txtDuracionRenta.Enabled = true;

            txtLongitudDuracion.ReadOnly = false;
            txtLongitudDuracion.Enabled = true;

            txtCostoReemplazo.ReadOnly = false;
            txtCostoReemplazo.Enabled = true;

            dtpLastUpdate.Enabled = true;

            cboClasificacionRating.Enabled = true;
            cboClasificacionRating.SelectedIndex = 0; // Selecciona el primer elemento por defecto
            cboLenguaje.Enabled = true;
            cboLenguaje.SelectedIndex = 0; // Selecciona el primer elemento por defecto

            txtTasaRenta.ReadOnly = false;
            txtTasaRenta.Enabled = true;
            txtReleaseYear.ReadOnly = false;
            txtReleaseYear.Enabled = true;
            txtTitulo.ReadOnly = false;
            txtTitulo.Enabled = true;


        }

        // Proxima secuencia
        protected void ProximoCodigo()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                int nCodigo = 0;

                // var oConexion = Procesos.ObtieneConexionDevart();
                SakilaDataContext dbContext = new SakilaDataContext();
                var oProximo = dbContext.ExecuteQuery<int>("Select max(film_id)+1 as maximo from film");

                if (oProximo != null)
                {
                    foreach (int id in oProximo)
                        this.txtCodigo.Text = id.ToString().Trim().PadLeft(5, '0');

                    // Reset the cursor to the default for all controls.
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                }
                else
                {
                    this.txtCodigo.Text = "00001";
                    // Reset the cursor to the default for all controls.
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error agregando Registro, Detalle: " + ex.Message, cSYSTEM, MessageBoxButtons.OK,
                     MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }

        }

        private void txtTitulo_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtCaracteristicas_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtReleaseYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtDuracionRenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtTasaRenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtCostoReemplazo_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void cboClasificacionRating_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }

        private void txtLongitudDuracion_KeyPress(object sender, KeyPressEventArgs e)
        {
            oProcesos.PasaTextbox_Enter(sender, e);
        }


        private void BuscarTablasRelacionadas(int nPelicula)
        {
            try
            {
                oProcesos.CursorOcupado();

                // DataContext takes a connection string
                SakilaDataContext db = new SakilaDataContext();

                // Buscamos lo Actores
                Table<FilmActor> oFilmActor = db.GetTable<FilmActor>();

                var oConsultaAcotres =
                from c in oFilmActor
                where c.FilmId == Convert.ToInt32(nPelicula)
                select c;

                foreach (var oActor in oConsultaAcotres)
                // Console.WriteLine("id = {0}, City = {1}", comp.CompanyID, comp.City);
                {
                    grdActores.Rows.Add(oActor.ActorId, oActor.Actor.FirstName + " " + oActor.Actor.LastName);

                }


                // Buscamos las Categorias  
                Table<Category> oCategorias = db.GetTable<Category>();

                var oConsultaCategoria =
                from c in oCategorias
                where c.CategoryId == Convert.ToInt32(nPelicula)
                select c;

                foreach (var oCategoria in oConsultaCategoria)
                // Console.WriteLine("id = {0}, City = {1}", comp.CompanyID, comp.City);
                {
                    grdCategorias.Rows.Add(oCategoria.CategoryId, oCategoria.Name);
                }



                // Buscamos Inventario              
                
                var reader = new WKBReader();
                Table<Inventory> oInventarios = db.GetTable<Inventory>();
                
                var oConsultaInventario =
                from c in oInventarios
                where c.FilmId == Convert.ToInt32(nPelicula)
                select c;
                
                foreach (var oInventario in oConsultaInventario)
                {   
                    grdInventario.Rows.Add(oInventario.Store.Address, oInventario.StoreId);                   
                }


                // Buscamos las rentas
                /*
                Table<Rental> oRentas = db.GetTable<Rental>();
                var oConsultaRentas = from c in oRentas
                where c.Inventory.FilmId == Convert.ToInt32(nPelicula)
                //    where c.fil == Convert.ToInt32(nPelicula)
                select c;
                foreach (var oRenta in oConsultaRentas)
                {
                   // grdRentas.Rows.Add(oRenta.Customer.FirstName + " " + oRenta.Customer.LastName, Convert.ToDateTime(oRenta.RentalDate));
                }
                */

                // Buscamos los pagos
                Table<Payment> oPagos = db.GetTable<Payment>();

                var oConsultaPagos =
                from c in oPagos
                where c.Rental.Inventory.FilmId == Convert.ToInt32(nPelicula)                  
                select c;

                foreach (var oPago in oConsultaPagos)
                // Console.WriteLine("id = {0}, City = {1}", comp.CompanyID, comp.City);
                {
                    grdRentas.Rows.Add(oPago.Customer.FirstName + " " + oPago.Customer.LastName, Convert.ToDateTime(oPago.PaymentDate), Convert.ToDecimal(oPago.Amount));
                }


                oProcesos.CursorPorDefecto();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error agregando Registro, Detalle: " + ex.Message, cSYSTEM, MessageBoxButtons.OK,
                     MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }
    }
}
