﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Data;
using VFPToolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;

namespace TurbiSoft
{
    public partial class frmTipoNovedad : frmBase
    {


        public String cModo = "Inicio";
        String cCadenaConexion = "";
        String cUsuarios = "";
        DataSet dsUsuarios = new DataSet();
        MySqlDataAdapter daUsuarios;
        DataTable dtUsuarios;
        DialogResult oOpcion;
        string cTabla = "tiponovedad";
        string campo = "";
        Procesos oProcesos = new Procesos();
        int nRegistros = 0;
        string cTablaMaestra = "tiponovedad";
        string cReporteMaestro = "";
        bool lVisualizaFoto = false;

        public frmTipoNovedad()
        {
            InitializeComponent();
        }

        private void frmBaseSimple_Load(object sender, EventArgs e)
        {
            this.cCadenaConexion = GlobalAccess.cnCadena();
            this.Iniciar();
        }

        protected void frmBaseMaestroFoto_Load(object sender, System.EventArgs e)
        {
            this.cCadenaConexion = GlobalAccess.cnCadena();
            this.Iniciar();

            // Combo Empleados
            cTabla = "empleados";
            string cOrderBy = " cod_emp";
            if (lVisualizaFoto == false)
            {
                /*
                this.imgFoto.Visible = false;
                cmdBuscarFoto.Visible = false;
                cmdCamara.Visible = false;
                 */
            }
        }

        public byte[] ImageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }

        protected void Iniciar()
        {
            this.cModo = "Inicio";
            this.Limpiar();
            this.Botones();

        } // Iniciar()

        protected void Limpiar()
        {
            Procesos.LimpiarTextBox(txtCodigo);
            oProcesos.LimpiarControles(this);
         //   this.imgFoto.ImageLocation = "";
         //   this.imgFoto.Image = null;

        } // fin Limpiar

        // Habiltia y desabilita botones
        protected void Botones()
        {
            switch (cModo)
            {
                case "Inicio":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = true;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    this.cmdEditar.Enabled = false;
                    oProcesos.LimpiarControles(this);
                    Procesos.Deshabilitar(this);
                    // txtcodigo.ReadOnly = false;
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                    this.UseWaitCursor = false;
                    Application.UseWaitCursor = false;

                    break;
                case "Nuevo":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = true;
                    this.cmdEditar.Enabled = false;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    Procesos.Habilitar(this);
                    // oProcesos.LimpiarControles(this);
                    break;

                case "Grabar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Eliminar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Cancelar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                    this.UseWaitCursor = false;
                    Application.UseWaitCursor = false;
                    break;

                case "Buscar":
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = true;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = false;
                    this.cmdEditar.Enabled = true;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;

                case "Actualiza":
                    this.cmdBorrar.Enabled = true;
                    this.cmdBuscar.Enabled = true;
                    //this.cmdLocaliza.Enabled = true;
                    this.cmdCancelar.Enabled = true;
                    this.cmdGrabar.Enabled = true;
                    this.cmdNuevo.Enabled = false;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    this.cmdEditar.Enabled = true;
                    Procesos.Habilitar(this);
                    break;

                default:
                    this.cmdBorrar.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.cmdCancelar.Enabled = false;
                    this.cmdGrabar.Enabled = false;
                    this.cmdNuevo.Enabled = true;
                    this.cmdPrinter.Enabled = true;
                    this.cmdSalir.Enabled = true;
                    break;
            }

            // Valida permisos del usuario
            this.cmdNuevo.Enabled = FrmMenInicio.oUserLogin.TienePermiso("110") && this.cmdNuevo.Enabled;
            this.cmdGrabar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("110") && this.cmdGrabar.Enabled;
            this.cmdEditar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("111") && this.cmdEditar.Enabled;
            this.cmdBuscar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("112") && this.cmdBuscar.Enabled;
            this.cmdBorrar.Enabled = FrmMenInicio.oUserLogin.TienePermiso("113") && this.cmdBorrar.Enabled;
            this.cmdPrinter.Enabled = FrmMenInicio.oUserLogin.TienePermiso("112") && this.cmdPrinter.Enabled;

        } // fin Botones

        // visualiza el registro que selecciona el usuario al navegar
        protected bool ValidaForm()
        {
            bool lRetorno = true;
         
            if (this.txtDescripcion.Text != "" || this.txtCodigo.Text != "")
            {
                lRetorno = true;
            }
            else
            {
                MessageBox.Show("Datos no pueden estar en blanco!!", FrmAcceso.cSYSTEM,
                           MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return lRetorno;
        }

        protected void DesHabilitar()
        {
            //txtcodigo.ReadOnly = true;
            oProcesos.AbilitarDesabilitarControles(this, false);
        }
        protected void Habilitar()
        {
            Procesos oProcesos = new Procesos();
            oProcesos.AbilitarDesabilitarControles(this, true);   
                       
            this.txtCodigo.ReadOnly = true;
            this.txtDescripcion.ReadOnly = false;
            this.txtDescripcion.Enabled = true;
        }

        // Proxima secuencia
        protected void ProximoCodigo()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                int nCodigo = 0;

                var oConexion = Procesos.ObtieneConexionDevart(FrmAcceso.nCodEmp);
                DevartDataContext dbContext = new DevartDataContext(oConexion);
                var oProximo = dbContext.ExecuteQuery<int>("Select max(Idtiponovedad)+1 from tiponovedad");

                if (oProximo != null )
                {
                    foreach (int id in oProximo)              
                    this.txtCodigo.Text = id.ToString().Trim().PadLeft(5,'0');

                    // Reset the cursor to the default for all controls.
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;
                }          
                else
                {
                    this.txtCodigo.Text = "00001";
                    // Reset the cursor to the default for all controls.
                    Cursor.Current = Cursors.Default;
                    this.Cursor = Cursors.Default;

                }               
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error agregando Registro, Detalle: " + ex.Message, FrmAcceso.cSYSTEM, MessageBoxButtons.OK,
                     MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }

        }

        // Pasa y formatatea los datos a las Variables 
        protected void PasarDatos()
        {



        }

        protected void cmdSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdNuevo_Click(object sender, System.EventArgs e)
        {
           
            cModo = "Nuevo";
            this.Botones();
            Habilitar();
            ProximoCodigo();
            this.txtDescripcion.Focus();
        }

        private void cmdSalir_Click_1(object sender, System.EventArgs e)
        {
            this.Close();
        }

        //**************************
        private void cmdGrabar_Click(object sender, System.EventArgs e)
        {
            try
            {
                if  (!this.ValidaForm())
                { return; } 

                     Cursor.Current = Cursors.WaitCursor;
                var oConexion = Procesos.ObtieneConexionDevart(FrmAcceso.nCodEmp);
                DevartDataContext DBContext = new DevartDataContext(oConexion);
                if (cModo == "Nuevo")
                    {

                        Tiponovedad  oTiponovedad = new Tiponovedad();
                    //   o Tiponovedad. Tiponovedad  = Convert.ToInt32(this.txtCodigo.Text);
                    oTiponovedad.Nomnovedad = txtDescripcion.Text.Trim();

                        // Inserto y grabo
                        DBContext. Tiponovedad.InsertOnSubmit(oTiponovedad);
                        DBContext.SubmitChanges();

                      var oUltimo = DBContext.ExecuteQuery<int>("select last_insert_id() as cLastID");
                      if (oUltimo != null) foreach (int id in oUltimo)              
                                             
                         MessageBox.Show("Registro Insertado Satisfactoriamente con la secuencia: " + id.ToString(), FrmAcceso.cSYSTEM,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                         this.Limpiar();
                         this.Botones();                       
                    }
                    else  // Editando Registro
                    {                       
                        var oConsulta = from user in DBContext. Tiponovedad 
                                        where user.Idtiponovedad  == Convert.ToInt32(txtCodigo.Text)
                                        select user;

                         Tiponovedad oTiponovedad = oConsulta.First();
                        oTiponovedad.Nomnovedad = txtDescripcion.Text.Trim();

                        // Grabo los cambios
                        DBContext.SubmitChanges();

                        MessageBox.Show("Registro actualizado Satisfactoriamente!!", FrmAcceso.cSYSTEM,
                                   MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Limpiar();
                        this.Botones();                
                       
                    }  // if (cModo == "Nuevo")


                    this.Iniciar();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error insertando y/o Actualizando Registro, Detalle: " + ex.Message, FrmAcceso.cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                ExceptionLog.LogError(ex, false);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;

            }
        }

        //************
        private void cmdBuscar_Click(object sender, System.EventArgs e)
        {
            try
            {
                frmBuscarTipoNovedad ofrmBuscarUsuario = new frmBuscarTipoNovedad();
                ofrmBuscarUsuario.ShowDialog();
                int nCoduser = ofrmBuscarUsuario.nCodigo;

                // Si selecciono un registro
                if (nCoduser != 0 && nCoduser != null)
                {
                    // DevartDataContext DBContext = new DevartDataContext();
                    var oConexion = Procesos.ObtieneConexionDevart(FrmAcceso.nCodEmp);
                    DevartDataContext dbContext = new DevartDataContext(oConexion);
                    var oConsulta = from user in dbContext.Tiponovedad
                                    where user.Idtiponovedad == Convert.ToInt32(nCoduser)
                                    select user;

                    Tiponovedad oTipoDocimg = oConsulta.First();
                    if (oTipoDocimg != null)
                    {
                        txtCodigo.Text = nCoduser.ToString().Trim();
                        txtDescripcion.Text = oTipoDocimg.Nomnovedad;
                        oProcesos.AbilitarDesabilitarControles(this, true);
                        Habilitar();
                        this.cModo = "Buscar";
                        this.Botones();
                        
                    }                        
                  }
                  else
                  {
                        MessageBox.Show("Este Tipo No Existe, Favor Revisar", FrmAcceso.cSYSTEM, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.txtCodigo.Text = "";
                        return;

                    } //   if (dsUsuario.Tables[0].Rows.Count > 0)              

                } // if (nCoduser != 0 && nCoduser != null)
            
            catch (Exception ex)
            {
                MessageBox.Show("Error Buscando Tipo Equipo, Detalle: " + ex.Message, FrmAcceso.cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                ExceptionLog.LogError(ex, false);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
    
            }
        }

        private void cmdCancelar_Click(object sender, System.EventArgs e)
        {
            this.Iniciar();
        }

        private void cmdBorrar_Click(object sender, System.EventArgs e)
        {
            if (this.txtCodigo.Text == "")
            {
                return;
            }
            DialogResult oRpt;
            oRpt = MessageBox.Show("Confirma que desea eliminar este registro?", FrmAcceso.cSYSTEM,
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (oRpt != DialogResult.Yes) { return; }
            try
            {
                bool lBorrado = false;
                cModo = "Eliminar";

                var oConexion = Procesos.ObtieneConexionDevart(FrmAcceso.nCodEmp);
                DevartDataContext DBContext = new DevartDataContext(oConexion);

                var oConsulta = from user in DBContext. Tiponovedad
                                    where user.Idtiponovedad == Convert.ToInt32(this.txtCodigo.Text)
                                    select user;

                     Tiponovedad oTiponovedad = oConsulta.First();
                    if (oTiponovedad != null)
                    {
                        DBContext. Tiponovedad.DeleteOnSubmit(oTiponovedad);
                        DBContext.SubmitChanges();
                        lBorrado = true;
                    }

                 if (lBorrado)
                {
                    MessageBox.Show("Registro Eliminado Satisfactoriamente!!", FrmAcceso.cSYSTEM,
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Iniciar();
                }
                else
                {
                    MessageBox.Show("No se pudo Eliminar el registro!!", FrmAcceso.cSYSTEM,
                           MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.txtCodigo.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error insertando Registro, Detalle: " + ex.Message, FrmAcceso.cSYSTEM, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                ExceptionLog.LogError(ex, false);
                Cursor.Current = Cursors.Default;
                this.Cursor = Cursors.Default;
                this.UseWaitCursor = false;
                Application.UseWaitCursor = false;
                return;
            }
        }

        private void cmdEditar_Click(object sender, System.EventArgs e)
        {
            cModo = "Actualiza";
            this.Botones();
            oProcesos.AbilitarDesabilitarControles(this, true);
            Habilitar();
            
        }

        private void txtDescripcion_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }
        }

        private void cmdPrinter_Click(object sender, EventArgs e)
        {

        }
    }
}
