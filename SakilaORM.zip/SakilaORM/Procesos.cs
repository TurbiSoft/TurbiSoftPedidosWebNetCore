﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TurbiSoft;
using SakilaContext;
using System.Runtime.CompilerServices;
using Org.BouncyCastle.Tls.Crypto;

namespace SakilaORM
{



    public class Procesos
    {
        public readonly static string ConectionString = "server=localhost;user id=root;password=*010405;database=SAKILA;Charset=utf8;port=3306;Convert Zero Datetime=True;Allow Zero Datetime=False";
        //ConectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SakilaDataContextConnectionString"].ConnectionString;
        const string cSYSTEM = "Práctica SAKILA DB ORM";
        public readonly static string ConectionStringDevart = "User Id=root;Password=*010405;Host=localhost;Database=sakila;Persist Security Info=True";

        public static MySqlConnection ObtieneConexion()
        {
            try
            {
                Procesos con = new Procesos();
                string constring = ConectionString; 

                MySqlConnection objCon = new MySqlConnection();
                objCon.ConnectionString = constring;
                objCon.Open();
                return objCon;
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Ha ocurriodo un error conectandose a la base de datos, Detalle del Error: " + cMensajeError, " Práctica SAKILA ORM", MessageBoxButtons.OK,
                      MessageBoxIcon.Information);
                // Reset the cursor to the default for all controls.
                Cursor.Current = Cursors.Default;
                Application.UseWaitCursor = false;
                return null;

            }
        }


        public string conectarConta()
        {
            Conexion oConexion = new Conexion();
            // return oConexion.conectar();
            return ConectionString;
        }


        public static string LimpiarTextBox(TextBox miTextBox1)
        {
            string lResultado = "";
            miTextBox1.Text = "";
            if (miTextBox1.Text == "")
            {
                lResultado = miTextBox1.Text;
            }

            return lResultado;
        }

        public void LimpiarControles(Control c)
        {
            foreach (Control Ctrl in c.Controls)
            {
                try
                {
                    //Console.WriteLine(Ctrl.GetType().ToString());
                    //MessageBox.Show ( (Ctrl.GetType().ToString())) ;
                    switch (Ctrl.GetType().ToString())
                    {
                        case "System.Windows.Forms.CheckBox":
                            ((CheckBox)Ctrl).Checked = false;
                            break;

                        case "System.Windows.Forms.TextBox":
                            ((TextBox)Ctrl).Text = "";
                            break;

                        case "System.Windows.Forms.RichTextBox":
                            ((RichTextBox)Ctrl).Text = "";
                            break;

                        case "System.Windows.Forms.ComboBox":
                            ((ComboBox)Ctrl).SelectedIndex = -1; //-1
                            break;

                        case "System.Windows.Forms.MaskedTextBox":

                            ((MaskedTextBox)Ctrl).Text = "";
                            break;

                        case "System.Windows.Forms.DateTimePicker":
                            ((DateTimePicker)Ctrl).Value = DateTime.Now;
                            break;

                        case "System.Windows.Forms.DataGridView":
                            ((DataGridView)Ctrl).Rows.Clear();
                            break;

                        // los habilito en Botones() del form
                        case "System.Windows.Forms.Button":
                            // ((MaskedTextBox)Ctrl).ReadOnly = false;
                            break;



                        case "Infragistics.Win.UltraWinMaskedEdit.UltraMaskedEdit":
                            //   ((Infragistics.Win.UltraMaskedEdit.UltraMaskedEdit)Ctrl).Text = "";
                            break;

                        case "Infragistics.Win.UltraWinEditors.UltraDateTimeEditor":
                            DateTime dt = DateTime.Now;
                            string shortDate = dt.ToShortDateString();
                            //        ((UltraDateTimeEditor)Ctrl).Text = shortDate;
                            break;

                        case " Infragistics.Win.UltraWinGrid.UltraCombo":
                            //         ((UltraCombo)Ctrl).Text = "";
                            break;

                        case "Infragistics.Win.UltraWinEditors.UltraCurrencyEditor":
                            //         ((UltraCurrencyEditor)Ctrl).Value = 0.0m;
                            break;

                        default:
                            if (Ctrl.Controls.Count > 0)
                                LimpiarControles(Ctrl);
                            break;
                    }
                }
                catch (Exception ex)
                {

                    string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                    MessageBox.Show("Error, Detalle: " + cMensajeError, "Resetear Controles, Sistema TurbiSoft Enterprise v1.0",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                finally
                {


                }
            }
        }


        // Turbi: Habilita y Deshabilita correctamente los controles
        public static void Deshabilitar(Control c)
        {
            foreach (Control Ctrl in c.Controls)
            {
                try
                {
                    //Console.WriteLine(Ctrl.GetType().ToString());
                    //MessageBox.Show ( (Ctrl.GetType().ToString())) ;
                    switch (Ctrl.GetType().ToString())
                    {
                        case "System.Windows.Forms.CheckBox":
                            ((CheckBox)Ctrl).Enabled = false;
                            break;

                        case "System.Windows.Forms.TextBox":
                            //((TextBox)Ctrl).Text = "";
                            ((TextBox)Ctrl).ReadOnly = true;
                            ((TextBox)Ctrl).Enabled = false;
                            break;

                        case "System.Windows.Forms.RadioButton":
                            ((RadioButton)Ctrl).Enabled = false;
                            break;

                        case "System.Windows.Forms.ComboBox":
                            ((ComboBox)Ctrl).Enabled = false;
                            break;

                        case "System.Windows.Forms.DateTimePicker":
                            ((DateTimePicker)Ctrl).Enabled = false;
                            break;

                        case "System.Windows.Forms.DataGridView":
                            ((DataGridView)Ctrl).Enabled = false;
                            break;



                        case "DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn":
                            // ((DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn)Ctrl).Enabled = false;
                            Ctrl.Enabled = false;
                            break;


                        case "System.Windows.Forms.MaskedTextBox":
                            ((MaskedTextBox)Ctrl).ReadOnly = true;
                            break;



                        default:
                            if (Ctrl.Controls.Count > 0)
                                Deshabilitar(Ctrl);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                    MessageBox.Show("Error, Detalle: " + cMensajeError, "Resetear Controles, Sistema TurbiSoft Enterprise v1.0",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);


                    return;
                }
                finally
                {


                }
            }
        }


        public static void Habilitar(Control c)
        {
            string cBasura = "";
            foreach (Control Ctrl in c.Controls)
            {
                try
                {
                    //Console.WriteLine(Ctrl.GetType().ToString());
                    //MessageBox.Show ( (Ctrl.GetType().ToString())) ;
                    switch (Ctrl.GetType().ToString())
                    {
                        case "System.Windows.Forms.CheckBox":
                            ((CheckBox)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.TextBox":
                            //((TextBox)Ctrl).Text = "";
                            ((TextBox)Ctrl).ReadOnly = false;
                            ((TextBox)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.RadioButton":
                            ((RadioButton)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.ComboBox":
                            ((ComboBox)Ctrl).Enabled = true;

                            break;

                        case "System.Windows.Forms.MaskedTextBox":
                            ((MaskedTextBox)Ctrl).ReadOnly = false;
                            break;

                        case "System.Windows.Forms.DateTimePicker":
                            ((DateTimePicker)Ctrl).Enabled = true;
                            break;

                        case "System.Windows.Forms.DataGridView":
                            ((DataGridView)Ctrl).Enabled = true;
                            break;

                        // los habilito en Botones() del form
                        case "System.Windows.Forms.Button":
                            // ((MaskedTextBox)Ctrl).ReadOnly = false;
                            break;


                        case "DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn":
                            // ((DevComponents.DotNetBar.Controls.DataGridViewComboBoxExColumn)Ctrl).Enabled = false;
                            Ctrl.Enabled = true;
                            break;


                        default:
                            if (Ctrl.Controls.Count > 0)
                            {
                                //  Deshabilitar(Ctrl); temporal 05-11-2024
                                int n = 1;
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                    MessageBox.Show("Error, Detalle: " + cMensajeError, "Resetear Controles, Sistema TurbiSoft Enterprise v1.0",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    return;
                }
                finally
                {

                }
            }
        }


        public void AbilitarDesabilitarControles(Form ofrm, bool lTrueFalse)
        {
            // hace un chequeo por todos los controles del formulario
            foreach (Control oControl in ofrm.Controls)
            {
                if (oControl is Button)
                {
                    // No hago nada, pues lo botones se deben habilitar en el metodo Botones
                    // de todos los formularios
                }
                else
                {
                    oControl.Enabled = lTrueFalse;
                    // oControl.ReadOnly = !lTrueFalse;
                }
            }
        }



        // Turbi 08-01-2016 Obtnene una conexion Devart con la cadena actual
        public static Devart.Data.MySql.MySqlConnection ObtieneConexionDevart()
        {
            try
            {
                // Busco la cadena de conexion segun la empresa activa
                Conexion con = new Conexion();
                string constring = con.conectar();

                Devart.Data.MySql.MySqlConnection objCon = new Devart.Data.MySql.MySqlConnection();
                objCon.ConnectionString = constring;
                objCon.Charset = "UTF8";
                objCon.Open();
                return objCon;
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                MessageBox.Show("Ha ocurriodo un error conectandose a la base de datos con Devart LinqConnect, Detalle del Error: " + cMensajeError, "", MessageBoxButtons.OK,
                      MessageBoxIcon.Information);
                // Reset the cursor to the default for all controls.
                Cursor.Current = Cursors.Default;
                Application.UseWaitCursor = false;
                return null;

            }

        }



        public static DataTable DatosGeneral(string tabla, string cOrderBy)
        {
            try
            {
                if (cOrderBy.Trim() == "" || cOrderBy == string.Empty)
                {
                    cOrderBy = "Order by 1 ";
                }

                DataTable dt = new DataTable();               
                string constring = ConectionString;
              //  if (constring == null) { constring = Conexion.ConectionString; }

                MySqlConnection objCon = new MySqlConnection();
                objCon.ConnectionString = constring;
                objCon.Open();

                string consulta = "SELECT * FROM " + tabla + " order by " + cOrderBy;
                MySqlCommand comando = new MySqlCommand(consulta, objCon);
                MySqlDataAdapter adap = new MySqlDataAdapter(comando);

                //Turbi
                //dt.Locale = System.Globalization.CultureInfo.InvariantCulture;

                adap.Fill(dt);
                objCon.Close();  // Turbi
                return dt;
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, "Bancos", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                
                return null;
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, "Bancos", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                // ExceptionLog.LogError(ex, false);
                return null;
            }

            finally
            {

            }
        }




        public static void LlenaComboBox(ComboBox miComboBox, string cTabla, string cOrderBy, string cDisplayMember, string cValueMeber, int nIndex)
        {
            //cTabla = "mpacientes";
            miComboBox.DataSource = Procesos.DatosGeneral(cTabla, cOrderBy);
            miComboBox.DisplayMember = cDisplayMember;
            miComboBox.ValueMember = cValueMeber;
            miComboBox.SelectedIndex = nIndex;
            miComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            miComboBox.AutoCompleteCustomSource = Procesos.AutocompleteGeneral(cDisplayMember, cTabla);
            miComboBox.AutoCompleteMode = AutoCompleteMode.None;
            miComboBox.AutoCompleteSource = AutoCompleteSource.ListItems;
        }
    


    // Turbi: SobreCarga metodo para cargar la coleccion de datos para el autocomplete
        public static AutoCompleteStringCollection AutocompleteGeneral(string campo, string cTabla)
        {
            if (cTabla.Trim() == "")
            {
                return AutocompleteGeneral(campo);
            }

            string tabla = cTabla;
            DataTable dt = DatosGeneral(tabla);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            //recorrer y cargar los items para el autocompletado
            foreach (DataRow row in dt.Rows)
            {
                coleccion.Add(Convert.ToString(row[campo]));
            }
            return coleccion;
        }


        //metodo para cargar los datos de la bd
        public static DataTable DatosGeneral(string tabla)
        {
            try
            {
                DataTable dt = new DataTable();
               
                string constring = ConectionString;

                MySqlConnection objCon = new MySqlConnection();
                objCon.ConnectionString = constring;
                objCon.Open();

                string consulta = "SELECT * FROM " + tabla + " "; //consulta a la tabla paises
                MySqlCommand comando = new MySqlCommand(consulta, objCon);

                MySqlDataAdapter adap = new MySqlDataAdapter(comando);

                //Turbi
                //dt.Locale = System.Globalization.CultureInfo.InvariantCulture;

                adap.Fill(dt);
                objCon.Close();
                return dt;
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, tabla, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
               
                return null;
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, tabla, MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
              
                return null;
            }
            finally
            {

            }
        }

       

        //metodo para cargar la coleccion de datos para el autocomplete
        public static AutoCompleteStringCollection AutocompleteGeneral(string campo)
        {
            string tabla = "catalogo";
            DataTable dt = DatosGeneral(tabla);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            //recorrer y cargar los items para el autocompletado
            foreach (DataRow row in dt.Rows)
            {
                coleccion.Add(Convert.ToString(row[campo]));
            }
            return coleccion;
        }

        // Key Press general
        public void PasaTextbox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }
        }


        // Turbi: Simula un InputBox  de fox y VB
        public DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            TextBox textBox = new TextBox();
            Button buttonOk = new Button();
            Button buttonCancel = new Button();

            form.Text = title;
            label.Text = promptText;
            textBox.Text = value;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(9, 20, 372, 13);
            textBox.SetBounds(12, 36, 372, 20);
            buttonOk.SetBounds(228, 72, 75, 23);
            buttonCancel.SetBounds(309, 72, 75, 23);

            label.AutoSize = true;
            textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
            buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            form.ClientSize = new Size(396, 107);
            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog();
            value = textBox.Text;
            return dialogResult;
        }


        public static DataTable Consulta(string sbQuery)
        {

            try
            {

                DataTable dt = new DataTable();
                Procesos con = new Procesos();
                
                MySqlConnection objCon = new MySqlConnection();
                objCon.ConnectionString = ConectionString;
                objCon.Open();

                //string consulta = "SELECT " + MIconsulta + " FROM " + tabla + " " + cFiltro + " group by " + cGroupBy + "";
                MySqlCommand comando = new MySqlCommand(sbQuery, objCon);
                comando.CommandTimeout = 0;
                MySqlDataAdapter adap = new MySqlDataAdapter(comando);


                //Turbi
                //dt.Locale = System.Globalization.CultureInfo.InvariantCulture;

                adap.Fill(dt);
                objCon.Close();
                return dt;
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, "Mi Contulta", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
               
                return null;
            }
            catch (Exception ex)
            {
                string cMensajeError = ex.Message + ", " + ((ex.InnerException != null) ? ex.InnerException.Message.Trim() : "").ToString();
                cMensajeError = cMensajeError + ", Fuente: " + ((ex.Source != null) ? ex.Source : "").ToString();
                MessageBox.Show("Error : " + cMensajeError, "Select_Personalizado", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                
                return null;
            }

            finally
            {

            }
        }



        // Turbi Muestra el cursor Ocupado o en proesos
        public void CursorOcupado()
        {
            Cursor.Current = Cursors.WaitCursor;
            //this.Cursor = Cursors.WaitCursor;
            // this.UseWaitCursor = WaitCursor;
            Application.UseWaitCursor = true;

        }

        // Turbi Muestra el cursor Ocupado o en proesos
        public void CursorPorDefecto()
        {
            Cursor.Current = Cursors.Default;
            //this.Cursor = Cursors.Default;
            //this.UseWaitCursor = false;
            Application.UseWaitCursor = false;
        }



    }  //  Clasesform
}  // namespace




