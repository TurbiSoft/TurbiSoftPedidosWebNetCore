﻿namespace TurbiSoft
{
    partial class frmBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBase));
            this.lblTituloForm = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            //this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.statusStripMainBar = new System.Windows.Forms.StatusStrip();
            this.StatusEmpresa = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusUsuario = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusMensajeSys = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusFecha = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusCaja = new System.Windows.Forms.ToolStripStatusLabel();
            this.ProgressBarMain = new System.Windows.Forms.ToolStripProgressBar();
            this.linqMonitor1 = new Devart.Data.Linq.Monitoring.LinqMonitor();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.statusStripMainBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTituloForm
            // 
            this.lblTituloForm.AutoEllipsis = true;
            this.lblTituloForm.BackColor = System.Drawing.SystemColors.Highlight;
            this.lblTituloForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblTituloForm.Location = new System.Drawing.Point(9, 7);
            this.lblTituloForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTituloForm.Name = "lblTituloForm";
            this.lblTituloForm.Size = new System.Drawing.Size(323, 30);
            this.lblTituloForm.TabIndex = 0;
            this.lblTituloForm.Text = "Maestro de Cuentas";
            this.lblTituloForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Location = new System.Drawing.Point(9, 39);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(686, 321);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // styleManager1
            // 
           // this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Office2007VistaGlass;
            // 
            // statusStripMainBar
            // 
            this.statusStripMainBar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.statusStripMainBar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStripMainBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusEmpresa,
            this.statusUsuario,
            this.statusMensajeSys,
            this.statusFecha,
            this.statusCaja,
            this.ProgressBarMain});
            this.statusStripMainBar.Location = new System.Drawing.Point(0, 361);
            this.statusStripMainBar.Name = "statusStripMainBar";
            this.statusStripMainBar.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStripMainBar.ShowItemToolTips = true;
            this.statusStripMainBar.Size = new System.Drawing.Size(704, 27);
            this.statusStripMainBar.TabIndex = 11;
            this.statusStripMainBar.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStripMainBar_ItemClicked);
            // 
            // StatusEmpresa
            // 
            this.StatusEmpresa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.StatusEmpresa.ForeColor = System.Drawing.Color.Red;
            this.StatusEmpresa.Name = "StatusEmpresa";
            this.StatusEmpresa.Size = new System.Drawing.Size(183, 22);
            this.StatusEmpresa.Text = "Nombre de la Empresa";
            // 
            // statusUsuario
            // 
            this.statusUsuario.Name = "statusUsuario";
            this.statusUsuario.Size = new System.Drawing.Size(47, 22);
            this.statusUsuario.Text = "Usuario";
            // 
            // statusMensajeSys
            // 
            this.statusMensajeSys.Name = "statusMensajeSys";
            this.statusMensajeSys.Size = new System.Drawing.Size(154, 22);
            this.statusMensajeSys.Text = "Mensaje Accion del Sistema";
            this.statusMensajeSys.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // statusFecha
            // 
            this.statusFecha.Name = "statusFecha";
            this.statusFecha.Size = new System.Drawing.Size(0, 22);
            // 
            // statusCaja
            // 
            this.statusCaja.Name = "statusCaja";
            this.statusCaja.Size = new System.Drawing.Size(33, 22);
            this.statusCaja.Text = "Caja:";
            // 
            // ProgressBarMain
            // 
            this.ProgressBarMain.Minimum = 1;
            this.ProgressBarMain.Name = "ProgressBarMain";
            this.ProgressBarMain.Size = new System.Drawing.Size(150, 21);
            this.ProgressBarMain.Value = 1;
            // 
            // linqMonitor1
            // 
            this.linqMonitor1.IsActive = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 388);
            this.Controls.Add(this.statusStripMainBar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTituloForm);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "frmBase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TurbiSoft Enterprise v7.0. Desarollado por VBS COMPUTER";
            this.Load += new System.EventHandler(this.frmBase_Load);
            this.statusStripMainBar.ResumeLayout(false);
            this.statusStripMainBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Label lblTituloForm;
        protected System.Windows.Forms.GroupBox groupBox1;
      //  private DevComponents.DotNetBar.StyleManager styleManager1;
        public System.Windows.Forms.StatusStrip statusStripMainBar;
        private System.Windows.Forms.ToolStripStatusLabel StatusEmpresa;
        private System.Windows.Forms.ToolStripStatusLabel statusUsuario;
        public System.Windows.Forms.ToolStripStatusLabel statusMensajeSys;
        private System.Windows.Forms.ToolStripStatusLabel statusFecha;
        private System.Windows.Forms.ToolStripStatusLabel statusCaja;
        public System.Windows.Forms.ToolStripProgressBar ProgressBarMain;
        private Devart.Data.Linq.Monitoring.LinqMonitor linqMonitor1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}