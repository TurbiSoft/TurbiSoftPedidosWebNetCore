﻿/**********************************************
 * 23-05-2020 Agregue Rango
 * 23-09-2020 Insude
 * 24-11-2020 valida usuario activos
 * ********************************************/

using SakilaORM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TurbiSoft
{
    public partial class frmBuscarFilm : frmBase
    {

        String cCadenaConexion = "";
        string cTabla = "Catalogo";
        string cListaCampo = "*";
        public String cCodigo = "";
        public string cCuenta = "";
        private DataSet dsCatalogo = new DataSet();        private DataTable dtCatalogo;
        const string cSYSTEM = "Práctica SAKILA DB ORM";

        Boolean lParaCorrespeondencia = true;
        Procesos Procesos = new Procesos();

        public frmBuscarFilm()
        {
            InitializeComponent();
        }

        private void frmBuscarEmpleado_Load(object sender, EventArgs e)
        {
            this.grdCatalogo.AutoGenerateColumns = false;
            
        }
        
        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            int nPos = 0;
            int nTodo = this.grdCatalogo.GetCellCount(DataGridViewElementStates.Selected);
            if (nTodo > 0)
            {
                int nFila = this.grdCatalogo.SelectedCells[nPos].RowIndex;
                int nCol = this.grdCatalogo.SelectedCells[nPos].ColumnIndex;
                this.cCodigo = Convert.ToString(grdCatalogo[nCol, nFila].Value);

                // forzo la primera columna para el codigo 
                this.cCodigo = Convert.ToString(grdCatalogo[0, nFila].Value);
            }
            this.grdCatalogo.Visible = true;
            this.Close();
        }

        private void cmdSalir_Click(object sender, EventArgs e)
        {
            this.cCodigo = "0";
            this.Close();
            
        }

        private void txtBuscar_Validated(object sender, EventArgs e)
        {
           
        }

        private void txtBuscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }
        }

        private void grdCatalogo_DoubleClick(object sender, EventArgs e)
        {
            int nPos = 0;
            int nTodo = this.grdCatalogo.GetCellCount(DataGridViewElementStates.Selected);
            if (nTodo > 0)
            {
                int nFila = this.grdCatalogo.SelectedCells[nPos].RowIndex;
                int nCol = this.grdCatalogo.SelectedCells[nPos].ColumnIndex;
                this.cCodigo = Convert.ToString(grdCatalogo[nCol, nFila].Value);

                // forzo la primera columna para el codigo 
                this.cCodigo = Convert.ToString(grdCatalogo[0, nFila].Value);
            }
            this.grdCatalogo.Visible = true;
            this.Close();
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (this.txtBuscar.Text != "")
            {
                // Version Consulta sin Store Procedure, solo string de consulta
                /*
                string cBuscar = "'%" + this.txtBuscar.Text.Trim().ToUpper() + "%'";
                string cConsultaSQL = "Select " + this.cListaCampo + " From " + this.cTabla + " where descrip  like " + cBuscar
                 + " or codigo like " + cBuscar + " order by descrip";*/

                // Version Consulta con Store Procedure parametrizado
                string cBuscar = "'%" + this.txtBuscar.Text.Trim() + "%'";

                DataTable dtEmpleados = Procesos.Consulta("select film_id,title  from film " +
                                                          "  where title like " + cBuscar + " or  description like " + cBuscar + " Order by title ");

                //  ReaSanto.AccesoDatos.clsManejoCatalogo oClsCatalogo = new ReaSanto.AccesoDatos.clsManejoCatalogo(this.cCadenaConexion);
                //   dsCatalogo = oClsCatalogo.Consulta_SelectLike(cBuscar);

                if (dtEmpleados.Rows.Count > 0)
                {
                    // borro las lineas del grid y datatable
                    this.grdCatalogo.Rows.Clear();

                    // Mostrar los datos del datatable en el grid
                    foreach (DataRow registro in dtEmpleados.Rows)
                    {

                        this.grdCatalogo.Rows.Add(registro["film_id"], registro["title"]);
                    }
                }
                else
                {
                    MessageBox.Show("No hubo coincidencia, favor intente de nuevo!!",cSYSTEM,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
