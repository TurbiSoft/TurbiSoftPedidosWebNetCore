﻿
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
// using Data;
// using VFPToolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;
using System.Xml;

namespace TurbiSoft
{
    public partial class frmBase : Form
    {

        public String cModo = "Inicio";
        protected String cCadenaConexion = "";//  Conexion.ConectionString;
        protected String cUsuarios = "";
        protected DataSet dsUsuarios = new DataSet();
        protected MySqlDataAdapter daUsuarios;
        protected DataTable dtUsuarios;
        protected DialogResult oOpcion;
        protected string cTabla = "tabla";
        protected string campo = "";
      //  Procesos oProcesos = new Procesos();
        protected int nRegistros = 0;
        protected string cTablaMaestra = "Master";
        protected string cTabldDetalle = "Detail";
        protected string cForeignKey =  "campo2";
        protected string cReporteMaestro = "reporte";
        protected string cPrimaryKey ="ID";
        protected bool lVisualizaFoto = false;
        

        public frmBase()
        {
            InitializeComponent();
        }

        private void frmBase_Load(object sender, EventArgs e)
        {
            // status bar
            /*
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Width = 300;
            this.Height = 125;
            



            StatusEmpresa.Text = FrmAcceso.nCodEmp.ToString() + " - " + FrmAcceso.cempresa.Trim();
            statusUsuario.Text = "             User: " + FrmAcceso.cUsuarioActual;
            statusMensajeSys.Text = "      " + FrmAcceso.cSYSTEM;
            ProgressBarMain.Value = 10;
            statusFecha.Text = "          " + DateTime.Today.ToLongDateString();
            linqMonitor1.IsActive = true;
            */
        }

        private void statusStripMainBar_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }


        /*
        public void Iniciar()
    {
        string cNada = "";
    }

        public void Limpiar();
        public void Muestra();
        public void Botones();
        public bool ValidaForm();
        public void Navegar();
        public void ProximoCodigo();
        public void CalculoTotal(); 
         */
    }
}
