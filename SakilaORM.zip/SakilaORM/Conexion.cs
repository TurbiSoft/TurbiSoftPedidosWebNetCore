﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
/*
using VFPToolkit;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using ReaSanto.LogicaNegocio;
*/
using System.Xml;
using System.Data.Odbc;

namespace TurbiSoft
{

    public class Conexion
    {
        private int nCodCia = 1;
        private string cCadena = "SakilaDataContextConnectionString";
        // 21-11-2015 Se debe validar  la empresa, para saber que cadena debe devolver
        // Cadena en empre_mo
       // public static string ConectionString = System.Configuration.ConfigurationManager.ConnectionStrings["TURBISOFT"].ConnectionString;
        public static string ConectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SakilaDataContextConnectionString"].ConnectionString;
        public static string ConectionStringMySQL = System.Configuration.ConfigurationManager.ConnectionStrings["SAKILA"].ConnectionString;
        public string cadconta { get; set; }

        public Conexion()
        {

           
                cCadena = "SakilaDataContextConnectionString";
                ConectionString =     System.Configuration.ConfigurationManager.ConnectionStrings[cCadena].ConnectionString;
                ConectionStringMySQL = System.Configuration.ConfigurationManager.ConnectionStrings["SAKILA"].ConnectionString;

        }
       


        public string conectar()
        {
            
               return ConectionString = System.Configuration.ConfigurationManager.ConnectionStrings[cCadena.Trim()].ConnectionString;
           
        }

        public string conectarMysql()
        {

            return ConectionStringMySQL = System.Configuration.ConfigurationManager.ConnectionStrings["SAKILA"].ConnectionString;

        }




    }
}
