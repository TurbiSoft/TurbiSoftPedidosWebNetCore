﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SakilaORM
{

    public class AppSettings
    {
        public ConnectionStrings ConnectionStrings { get; set; }
    }

    public class ConnectionStrings
    {
        public string MySqlConnection { get; set; }
        public string SakilaDataContextConnectionString = "User Id=root;Password=*010405;Host=localhost;Database=sakila;Persist Security Info=True";
    }

    /*
    
            var json = File.ReadAllText("appsettings.json");
            var settings = JsonSerializer.Deserialize<AppSettings>(json);
            string connectionString = settings.ConnectionStrings.SakilaDataContextConnectionString;
            return connectionString;

            /*
            var configurationBuilder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: true, reloadOnChange: false);
            var configuration = configurationBuilder.Build();
            return configuration.GetConnectionString(connectionStringName);
            */    

    }
