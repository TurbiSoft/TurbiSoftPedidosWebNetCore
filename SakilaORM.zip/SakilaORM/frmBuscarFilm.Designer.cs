﻿namespace TurbiSoft
{
    partial class frmBuscarFilm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuscarFilm));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            cmdAceptar = new Button();
            cmdSalir = new Button();
            txtBuscar = new TextBox();
            label1 = new Label();
            grdCatalogo = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Descrip = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dsUsuarios).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdCatalogo).BeginInit();
            SuspendLayout();
            // 
            // lblTituloForm
            // 
            lblTituloForm.Size = new Size(423, 23);
            lblTituloForm.Text = "Busqueda Avanzada de Películas";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(grdCatalogo);
            groupBox1.Controls.Add(cmdAceptar);
            groupBox1.Controls.Add(cmdSalir);
            groupBox1.Controls.Add(txtBuscar);
            groupBox1.Controls.Add(label1);
            groupBox1.Size = new Size(655, 385);
            // 
            // cmdAceptar
            // 
            cmdAceptar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            cmdAceptar.DialogResult = DialogResult.Cancel;
            cmdAceptar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdAceptar.ForeColor = SystemColors.HotTrack;
            cmdAceptar.Image = (Image)resources.GetObject("cmdAceptar.Image");
            cmdAceptar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdAceptar.Location = new Point(417, 335);
            cmdAceptar.Name = "cmdAceptar";
            cmdAceptar.Size = new Size(95, 42);
            cmdAceptar.TabIndex = 8;
            cmdAceptar.Text = "&Aceptar";
            cmdAceptar.TextAlign = ContentAlignment.MiddleRight;
            cmdAceptar.UseVisualStyleBackColor = true;
            cmdAceptar.Click += cmdAceptar_Click;
            // 
            // cmdSalir
            // 
            cmdSalir.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            cmdSalir.DialogResult = DialogResult.Cancel;
            cmdSalir.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdSalir.ForeColor = SystemColors.HotTrack;
            cmdSalir.Image = (Image)resources.GetObject("cmdSalir.Image");
            cmdSalir.ImageAlign = ContentAlignment.MiddleLeft;
            cmdSalir.Location = new Point(512, 335);
            cmdSalir.Name = "cmdSalir";
            cmdSalir.Size = new Size(95, 42);
            cmdSalir.TabIndex = 9;
            cmdSalir.Text = "&Cancelar";
            cmdSalir.TextAlign = ContentAlignment.MiddleRight;
            cmdSalir.UseVisualStyleBackColor = true;
            cmdSalir.Click += cmdSalir_Click;
            // 
            // txtBuscar
            // 
            txtBuscar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtBuscar.CharacterCasing = CharacterCasing.Upper;
            txtBuscar.Location = new Point(89, 37);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(517, 20);
            txtBuscar.TabIndex = 5;
            txtBuscar.TextChanged += txtBuscar_TextChanged;
            txtBuscar.KeyPress += txtBuscar_KeyPress;
            txtBuscar.Validated += txtBuscar_Validated;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(26, 39);
            label1.Name = "label1";
            label1.Size = new Size(63, 17);
            label1.TabIndex = 6;
            label1.Text = "Buscar:";
            // 
            // grdCatalogo
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 255, 192);
            grdCatalogo.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            grdCatalogo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCatalogo.Columns.AddRange(new DataGridViewColumn[] { Codigo, Descrip });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(192, 255, 192);
            dataGridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            grdCatalogo.DefaultCellStyle = dataGridViewCellStyle2;
            grdCatalogo.Location = new Point(51, 63);
            grdCatalogo.Name = "grdCatalogo";
            grdCatalogo.ReadOnly = true;
            grdCatalogo.RowHeadersVisible = false;
            grdCatalogo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdCatalogo.Size = new Size(555, 268);
            grdCatalogo.TabIndex = 11;
            grdCatalogo.DoubleClick += grdCatalogo_DoubleClick;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "Código";
            Codigo.Name = "Codigo";
            Codigo.ReadOnly = true;
            Codigo.Width = 150;
            // 
            // Descrip
            // 
            Descrip.HeaderText = "Nombres";
            Descrip.Name = "Descrip";
            Descrip.ReadOnly = true;
            Descrip.Width = 400;
            // 
            // frmBuscarFilm
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(679, 436);
            Name = "frmBuscarFilm";
            Text = "Busqueda Avanzada de Peliculas";
            Load += frmBuscarEmpleado_Load;
            ((System.ComponentModel.ISupportInitialize)dsUsuarios).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdCatalogo).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.Button cmdSalir;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grdCatalogo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Codigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descrip;
    }
}