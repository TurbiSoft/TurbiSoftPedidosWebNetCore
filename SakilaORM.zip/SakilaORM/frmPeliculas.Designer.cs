﻿namespace SakilaORM
{
    partial class frmPeliculas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPeliculas));
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            cmdNuevo = new Button();
            cmdGrabar = new Button();
            cmdEditar = new Button();
            cmdBuscar = new Button();
            cmdBorrar = new Button();
            cmdCancelar = new Button();
            cmdSalir = new Button();
            cmdPrinter = new Button();
            txtCodigo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtTitulo = new TextBox();
            label3 = new Label();
            txtDescripcion = new TextBox();
            label4 = new Label();
            txtReleaseYear = new TextBox();
            label5 = new Label();
            txtCaracteristicas = new TextBox();
            label6 = new Label();
            label7 = new Label();
            txtCostoReemplazo = new TextBox();
            label8 = new Label();
            txtLongitudDuracion = new TextBox();
            label9 = new Label();
            txtDuracionRenta = new TextBox();
            dtpLastUpdate = new DateTimePicker();
            cboClasificacionRating = new ComboBox();
            label10 = new Label();
            label11 = new Label();
            cboLenguaje = new ComboBox();
            label12 = new Label();
            txtTasaRenta = new TextBox();
            grdActores = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Descrip = new DataGridViewTextBoxColumn();
            grdCategorias = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            grdInventario = new DataGridView();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            grdRentas = new DataGridView();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            Importe = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dsUsuarios).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdActores).BeginInit();
            ((System.ComponentModel.ISupportInitialize)grdCategorias).BeginInit();
            ((System.ComponentModel.ISupportInitialize)grdInventario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)grdRentas).BeginInit();
            SuspendLayout();
            // 
            // lblTituloForm
            // 
            lblTituloForm.Location = new Point(8, 6);
            lblTituloForm.Size = new Size(277, 26);
            lblTituloForm.Text = "Maestro de Películas";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(grdRentas);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(grdInventario);
            groupBox1.Controls.Add(grdCategorias);
            groupBox1.Controls.Add(grdActores);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(txtTasaRenta);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(cboLenguaje);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(cboClasificacionRating);
            groupBox1.Controls.Add(dtpLastUpdate);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtCostoReemplazo);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(txtLongitudDuracion);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(txtDuracionRenta);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtReleaseYear);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(txtCaracteristicas);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtDescripcion);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtTitulo);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtCodigo);
            groupBox1.Location = new Point(8, 34);
            groupBox1.Size = new Size(968, 502);
            // 
            // cmdNuevo
            // 
            cmdNuevo.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdNuevo.Image = (Image)resources.GetObject("cmdNuevo.Image");
            cmdNuevo.ImageAlign = ContentAlignment.MiddleLeft;
            cmdNuevo.Location = new Point(33, 541);
            cmdNuevo.Name = "cmdNuevo";
            cmdNuevo.Size = new Size(114, 46);
            cmdNuevo.TabIndex = 12;
            cmdNuevo.Text = "&Nuevo";
            cmdNuevo.TextAlign = ContentAlignment.MiddleRight;
            cmdNuevo.UseVisualStyleBackColor = true;
            cmdNuevo.Click += cmdNuevo_Click;
            // 
            // cmdGrabar
            // 
            cmdGrabar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdGrabar.Image = (Image)resources.GetObject("cmdGrabar.Image");
            cmdGrabar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdGrabar.Location = new Point(145, 541);
            cmdGrabar.Name = "cmdGrabar";
            cmdGrabar.Size = new Size(114, 46);
            cmdGrabar.TabIndex = 13;
            cmdGrabar.Text = " &Grabar";
            cmdGrabar.TextAlign = ContentAlignment.MiddleRight;
            cmdGrabar.UseVisualStyleBackColor = true;
            cmdGrabar.Click += cmdGrabar_Click;
            // 
            // cmdEditar
            // 
            cmdEditar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdEditar.Image = (Image)resources.GetObject("cmdEditar.Image");
            cmdEditar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdEditar.Location = new Point(374, 541);
            cmdEditar.Name = "cmdEditar";
            cmdEditar.Size = new Size(114, 46);
            cmdEditar.TabIndex = 15;
            cmdEditar.Text = "&Modificar";
            cmdEditar.TextAlign = ContentAlignment.MiddleRight;
            cmdEditar.UseVisualStyleBackColor = true;
            cmdEditar.Click += cmdEditar_Click;
            // 
            // cmdBuscar
            // 
            cmdBuscar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdBuscar.Image = (Image)resources.GetObject("cmdBuscar.Image");
            cmdBuscar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdBuscar.Location = new Point(259, 541);
            cmdBuscar.Name = "cmdBuscar";
            cmdBuscar.Size = new Size(114, 46);
            cmdBuscar.TabIndex = 14;
            cmdBuscar.Text = "&Buscar";
            cmdBuscar.TextAlign = ContentAlignment.MiddleRight;
            cmdBuscar.UseVisualStyleBackColor = true;
            cmdBuscar.Click += cmdBuscar_Click;
            // 
            // cmdBorrar
            // 
            cmdBorrar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdBorrar.Image = (Image)resources.GetObject("cmdBorrar.Image");
            cmdBorrar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdBorrar.Location = new Point(601, 541);
            cmdBorrar.Name = "cmdBorrar";
            cmdBorrar.Size = new Size(114, 46);
            cmdBorrar.TabIndex = 17;
            cmdBorrar.Text = "&Eliminar";
            cmdBorrar.TextAlign = ContentAlignment.MiddleRight;
            cmdBorrar.UseVisualStyleBackColor = true;
            cmdBorrar.Click += cmdBorrar_Click;
            // 
            // cmdCancelar
            // 
            cmdCancelar.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdCancelar.Image = (Image)resources.GetObject("cmdCancelar.Image");
            cmdCancelar.ImageAlign = ContentAlignment.MiddleLeft;
            cmdCancelar.Location = new Point(488, 541);
            cmdCancelar.Name = "cmdCancelar";
            cmdCancelar.Size = new Size(114, 46);
            cmdCancelar.TabIndex = 16;
            cmdCancelar.Text = "&Cancel";
            cmdCancelar.TextAlign = ContentAlignment.MiddleRight;
            cmdCancelar.UseVisualStyleBackColor = true;
            cmdCancelar.Click += cmdCancelar_Click;
            // 
            // cmdSalir
            // 
            cmdSalir.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdSalir.Image = (Image)resources.GetObject("cmdSalir.Image");
            cmdSalir.ImageAlign = ContentAlignment.MiddleLeft;
            cmdSalir.Location = new Point(830, 541);
            cmdSalir.Name = "cmdSalir";
            cmdSalir.Size = new Size(114, 46);
            cmdSalir.TabIndex = 19;
            cmdSalir.Text = "&Salir";
            cmdSalir.TextAlign = ContentAlignment.MiddleRight;
            cmdSalir.UseVisualStyleBackColor = true;
            cmdSalir.Click += cmdSalir_Click;
            // 
            // cmdPrinter
            // 
            cmdPrinter.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold);
            cmdPrinter.Image = (Image)resources.GetObject("cmdPrinter.Image");
            cmdPrinter.ImageAlign = ContentAlignment.MiddleLeft;
            cmdPrinter.Location = new Point(714, 541);
            cmdPrinter.Name = "cmdPrinter";
            cmdPrinter.Size = new Size(114, 46);
            cmdPrinter.TabIndex = 18;
            cmdPrinter.Text = "&Listado";
            cmdPrinter.TextAlign = ContentAlignment.MiddleRight;
            cmdPrinter.UseVisualStyleBackColor = true;
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(124, 28);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(117, 20);
            txtCodigo.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(72, 28);
            label1.Name = "label1";
            label1.Size = new Size(40, 13);
            label1.TabIndex = 1;
            label1.Text = "Código";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(79, 51);
            label2.Name = "label2";
            label2.Size = new Size(33, 13);
            label2.TabIndex = 3;
            label2.Text = "Titulo";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(124, 51);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(434, 20);
            txtTitulo.TabIndex = 2;
            txtTitulo.KeyPress += txtTitulo_KeyPress;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(49, 80);
            label3.Name = "label3";
            label3.Size = new Size(63, 13);
            label3.TabIndex = 5;
            label3.Text = "Descripción";
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new Point(124, 75);
            txtDescripcion.Multiline = true;
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(434, 33);
            txtDescripcion.TabIndex = 4;
            txtDescripcion.KeyPress += txtDescripcion_KeyPress;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(29, 154);
            label4.Name = "label4";
            label4.Size = new Size(83, 13);
            label4.TabIndex = 9;
            label4.Text = "Año Produccion";
            // 
            // txtReleaseYear
            // 
            txtReleaseYear.Location = new Point(124, 154);
            txtReleaseYear.Name = "txtReleaseYear";
            txtReleaseYear.Size = new Size(62, 20);
            txtReleaseYear.TabIndex = 8;
            txtReleaseYear.KeyPress += txtReleaseYear_KeyPress;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(36, 113);
            label5.Name = "label5";
            label5.Size = new Size(76, 13);
            label5.TabIndex = 7;
            label5.Text = "Carecteristcias";
            // 
            // txtCaracteristicas
            // 
            txtCaracteristicas.Location = new Point(124, 113);
            txtCaracteristicas.Multiline = true;
            txtCaracteristicas.Name = "txtCaracteristicas";
            txtCaracteristicas.Size = new Size(434, 35);
            txtCaracteristicas.TabIndex = 6;
            txtCaracteristicas.KeyPress += txtCaracteristicas_KeyPress;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(586, 53);
            label6.Name = "label6";
            label6.Size = new Size(101, 13);
            label6.TabIndex = 17;
            label6.Text = "Ultima actualización";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(232, 180);
            label7.Name = "label7";
            label7.Size = new Size(90, 13);
            label7.TabIndex = 15;
            label7.Text = "Costo Reemplazo";
            // 
            // txtCostoReemplazo
            // 
            txtCostoReemplazo.Location = new Point(366, 180);
            txtCostoReemplazo.Name = "txtCostoReemplazo";
            txtCostoReemplazo.Size = new Size(117, 20);
            txtCostoReemplazo.TabIndex = 14;
            txtCostoReemplazo.KeyPress += txtCostoReemplazo_KeyPress;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(597, 131);
            label8.Name = "label8";
            label8.Size = new Size(90, 13);
            label8.TabIndex = 13;
            label8.Text = "Minutos Duración";
            // 
            // txtLongitudDuracion
            // 
            txtLongitudDuracion.Location = new Point(699, 131);
            txtLongitudDuracion.Name = "txtLongitudDuracion";
            txtLongitudDuracion.Size = new Size(62, 20);
            txtLongitudDuracion.TabIndex = 12;
            txtLongitudDuracion.KeyPress += txtLongitudDuracion_KeyPress;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 180);
            label9.Name = "label9";
            label9.Size = new Size(103, 13);
            label9.TabIndex = 11;
            label9.Text = "Durancion de Renta";
            // 
            // txtDuracionRenta
            // 
            txtDuracionRenta.Location = new Point(124, 177);
            txtDuracionRenta.Name = "txtDuracionRenta";
            txtDuracionRenta.Size = new Size(62, 20);
            txtDuracionRenta.TabIndex = 10;
            txtDuracionRenta.KeyPress += txtDuracionRenta_KeyPress;
            // 
            // dtpLastUpdate
            // 
            dtpLastUpdate.Location = new Point(699, 51);
            dtpLastUpdate.Name = "dtpLastUpdate";
            dtpLastUpdate.Size = new Size(200, 20);
            dtpLastUpdate.TabIndex = 18;
            // 
            // cboClasificacionRating
            // 
            cboClasificacionRating.FormattingEnabled = true;
            cboClasificacionRating.Location = new Point(699, 77);
            cboClasificacionRating.Name = "cboClasificacionRating";
            cboClasificacionRating.Size = new Size(121, 21);
            cboClasificacionRating.TabIndex = 19;
            cboClasificacionRating.KeyPress += cboClasificacionRating_KeyPress;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(621, 80);
            label10.Name = "label10";
            label10.Size = new Size(66, 13);
            label10.TabIndex = 20;
            label10.Text = "Clasificación";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(649, 107);
            label11.Name = "label11";
            label11.Size = new Size(38, 13);
            label11.TabIndex = 22;
            label11.Text = "Idioma";
            // 
            // cboLenguaje
            // 
            cboLenguaje.FormattingEnabled = true;
            cboLenguaje.Location = new Point(699, 104);
            cboLenguaje.Name = "cboLenguaje";
            cboLenguaje.Size = new Size(121, 21);
            cboLenguaje.TabIndex = 21;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(264, 154);
            label12.Name = "label12";
            label12.Size = new Size(63, 13);
            label12.TabIndex = 24;
            label12.Text = "Tasa Renta";
            // 
            // txtTasaRenta
            // 
            txtTasaRenta.Location = new Point(366, 154);
            txtTasaRenta.Name = "txtTasaRenta";
            txtTasaRenta.Size = new Size(117, 20);
            txtTasaRenta.TabIndex = 23;
            txtTasaRenta.KeyPress += txtTasaRenta_KeyPress;
            // 
            // grdActores
            // 
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(255, 255, 192);
            grdActores.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            grdActores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdActores.Columns.AddRange(new DataGridViewColumn[] { Codigo, Descrip });
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.FromArgb(192, 255, 192);
            dataGridViewCellStyle12.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle12.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.False;
            grdActores.DefaultCellStyle = dataGridViewCellStyle12;
            grdActores.Location = new Point(95, 348);
            grdActores.Name = "grdActores";
            grdActores.ReadOnly = true;
            grdActores.RowHeadersVisible = false;
            grdActores.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdActores.Size = new Size(379, 136);
            grdActores.TabIndex = 25;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "Código";
            Codigo.Name = "Codigo";
            Codigo.ReadOnly = true;
            // 
            // Descrip
            // 
            Descrip.HeaderText = "Nombre del Actor";
            Descrip.Name = "Descrip";
            Descrip.ReadOnly = true;
            Descrip.Width = 400;
            // 
            // grdCategorias
            // 
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.FromArgb(255, 255, 192);
            grdCategorias.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            grdCategorias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCategorias.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2 });
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = Color.FromArgb(192, 255, 192);
            dataGridViewCellStyle10.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle10.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.False;
            grdCategorias.DefaultCellStyle = dataGridViewCellStyle10;
            grdCategorias.Location = new Point(122, 209);
            grdCategorias.Name = "grdCategorias";
            grdCategorias.ReadOnly = true;
            grdCategorias.RowHeadersVisible = false;
            grdCategorias.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdCategorias.Size = new Size(259, 136);
            grdCategorias.TabIndex = 26;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.HeaderText = "Código";
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.HeaderText = "Nombre de la Categoria";
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 400;
            // 
            // grdInventario
            // 
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(255, 255, 192);
            grdInventario.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            grdInventario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdInventario.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn3 });
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(192, 255, 192);
            dataGridViewCellStyle8.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            grdInventario.DefaultCellStyle = dataGridViewCellStyle8;
            grdInventario.Location = new Point(480, 348);
            grdInventario.Name = "grdInventario";
            grdInventario.ReadOnly = true;
            grdInventario.RowHeadersVisible = false;
            grdInventario.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdInventario.Size = new Size(456, 136);
            grdInventario.TabIndex = 27;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.HeaderText = "Datos de la Tienda";
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            dataGridViewTextBoxColumn4.Width = 300;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewTextBoxColumn3.HeaderText = "Stock";
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Red;
            label13.Location = new Point(1, 220);
            label13.Name = "label13";
            label13.Size = new Size(117, 25);
            label13.TabIndex = 28;
            label13.Text = "Categorías";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.Red;
            label14.Location = new Point(4, 370);
            label14.Name = "label14";
            label14.Size = new Size(86, 25);
            label14.TabIndex = 29;
            label14.Text = "Actores";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Red;
            label15.Location = new Point(621, 320);
            label15.Name = "label15";
            label15.Size = new Size(184, 25);
            label15.TabIndex = 30;
            label15.Text = "Inventario (Stock)";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Red;
            label16.Location = new Point(389, 208);
            label16.Name = "label16";
            label16.Size = new Size(79, 25);
            label16.TabIndex = 32;
            label16.Text = "Rentas";
            // 
            // grdRentas
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 255, 192);
            grdRentas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            grdRentas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRentas.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, Importe });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(192, 255, 192);
            dataGridViewCellStyle5.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            grdRentas.DefaultCellStyle = dataGridViewCellStyle5;
            grdRentas.Location = new Point(474, 197);
            grdRentas.Name = "grdRentas";
            grdRentas.ReadOnly = true;
            grdRentas.RowHeadersVisible = false;
            grdRentas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdRentas.Size = new Size(462, 120);
            grdRentas.TabIndex = 31;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle2.NullValue = null;
            dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewTextBoxColumn5.HeaderText = "Cliente";
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            dataGridViewTextBoxColumn5.Width = 300;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewTextBoxColumn6.HeaderText = "Fecha";
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            dataGridViewTextBoxColumn6.ReadOnly = true;
            dataGridViewTextBoxColumn6.Width = 75;
            // 
            // Importe
            // 
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.NullValue = null;
            Importe.DefaultCellStyle = dataGridViewCellStyle4;
            Importe.HeaderText = "Importe";
            Importe.Name = "Importe";
            Importe.ReadOnly = true;
            Importe.Width = 75;
            // 
            // frmPeliculas
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = cmdSalir;
            ClientSize = new Size(987, 644);
            Controls.Add(cmdSalir);
            Controls.Add(cmdPrinter);
            Controls.Add(cmdBorrar);
            Controls.Add(cmdCancelar);
            Controls.Add(cmdEditar);
            Controls.Add(cmdBuscar);
            Controls.Add(cmdGrabar);
            Controls.Add(cmdNuevo);
            Name = "frmPeliculas";
            Text = "Maestro de Películas";
            Load += frmPeliculas_Load;
            Controls.SetChildIndex(lblTituloForm, 0);
            Controls.SetChildIndex(groupBox1, 0);
            Controls.SetChildIndex(cmdNuevo, 0);
            Controls.SetChildIndex(cmdGrabar, 0);
            Controls.SetChildIndex(cmdBuscar, 0);
            Controls.SetChildIndex(cmdEditar, 0);
            Controls.SetChildIndex(cmdCancelar, 0);
            Controls.SetChildIndex(cmdBorrar, 0);
            Controls.SetChildIndex(cmdPrinter, 0);
            Controls.SetChildIndex(cmdSalir, 0);
            ((System.ComponentModel.ISupportInitialize)dsUsuarios).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdActores).EndInit();
            ((System.ComponentModel.ISupportInitialize)grdCategorias).EndInit();
            ((System.ComponentModel.ISupportInitialize)grdInventario).EndInit();
            ((System.ComponentModel.ISupportInitialize)grdRentas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button cmdNuevo;
        private Button cmdGrabar;
        private Button cmdEditar;
        private Button cmdBuscar;
        private Button cmdBorrar;
        private Button cmdCancelar;
        private Button cmdSalir;
        private Button cmdPrinter;
        private Label label1;
        private TextBox txtCodigo;
        private Label label4;
        private TextBox txtReleaseYear;
        private Label label5;
        private TextBox txtCaracteristicas;
        private Label label3;
        private TextBox txtDescripcion;
        private Label label2;
        private TextBox txtTitulo;
        private Label label10;
        private ComboBox cboClasificacionRating;
        private DateTimePicker dtpLastUpdate;
        private Label label6;
        private Label label7;
        private TextBox txtCostoReemplazo;
        private Label label8;
        private TextBox txtLongitudDuracion;
        private Label label9;
        private TextBox txtDuracionRenta;
        private Label label11;
        private ComboBox cboLenguaje;
        private Label label12;
        private TextBox txtTasaRenta;
        private DataGridView grdCategorias;
        private DataGridView grdActores;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Descrip;
        private DataGridView grdInventario;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label16;
        private DataGridView grdRentas;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn Importe;
    }
}
